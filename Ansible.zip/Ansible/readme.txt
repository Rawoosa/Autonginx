This is my attempt to create an autoinstaller for nginx using Ansible.
I really like Ansible, it looks harder than it is, there is a lot of
documentation and if even I managed to create this, then you'll definitely too

Please, before running this playbook, install additional package for Ansible
by executing command: ansible-galaxy collection install community.general

To run this playbook, make sure that you're in <path where you unpacked my
archive>/ (I mean, you're in a folder, where this txt is located) and
execute this command: ansible-playbook main.yml -Kk

Good luck using this, hope that will work

P.S. You should check hosts and site.conf to avoid any UNFORSEEN CONSEQUENCES
